# dossier-rag

A small, free, local document library for regulatory efficacy work (BAD / dRR drafting, zRMS answers): Markdown conversion, Camelot table extraction, and search with citations, in one SQLite file.

```
PDF / Word / Excel / ARM export / folder / .zip
        │  convert   pdftotext (2-column text) · Camelot (tables) · pandoc (Word) · pandas (Excel)
        ▼
Markdown + one CSV per table             ← human-readable, diffable
        │  index
        ▼
library/dossier.db
  ├─ chunks + FTS5 (BM25, stemming, regulatory synonyms) → search guidance text, with citations
  ├─ tbl_N tables (+ __num / __letters columns)         → query trial numbers with SQL
  └─ optional embeddings (model2vec)                    → hybrid search where a model is available
```

**Text is searched; numbers are queried.** Efficacy %, rates and statistical letters are never "retrieved by similarity". They come from the extracted tables through SQL, so they can't be mixed up between trials.

## Install

```bash
pip install git+https://github.com/namanothing-code/dossier-rag            # keyword search
pip install "dossier-rag[semantic] @ git+https://github.com/namanothing-code/dossier-rag"   # + embeddings
```

Uses `pdftotext` (poppler), `pandoc` and `ocrmypdf` when present.

## Commands

```bash
dossier-rag ingest  report.pdf trials/ archive.zip --lib library   # convert + index (re-ingest replaces)
dossier-rag search  "crop safety trials for herbicides" --lib library [-k 8] [--kind table] [--source NAME] [--full] [--json]
dossier-rag show    40 --lib library                                # one chunk in full
dossier-rag tables  --lib library [--find efficacy]                 # table catalog: tbl_N, source, page, columns
dossier-rag sql     'SELECT * FROM tbl_7 WHERE "Efficacy % 28 DAA__num" >= 80' --lib library   # read-only
dossier-rag reindex PP1_307_2 --lib library                        # after hand-fixing its .md / CSVs
dossier-rag verify  PP1_307_2 --note "tables 1-4 checked vs PDF" --lib library
dossier-rag stats   --lib library
dossier-rag pack    --lib library --out library.zip                 # carry the library to another chat/machine
dossier-rag restore library.zip --lib library                       # (ingest also restores a packed zip)
```

## Design choices

| Requirement | Choice | Why |
|---|---|---|
| Free / open source, no server | SQLite (FTS5) single file | runs anywhere, easy to zip and move |
| Exact regulatory terms (`PP 1/135`, BBCH 13, product codes) | BM25 keyword search, quoted phrases | semantic search often misses exact codes |
| Wording differences (efficacy/effectiveness, crop safety/phytotoxicity/selectivity) | built-in synonym groups + Porter stemming | works without any model download |
| Rank the passage that answers the question | all-concepts matches ranked above partial matches; table captions weighted | tables are usually the answer in standards |
| Meaning-based search | optional model2vec embeddings, fused with BM25 (reciprocal rank fusion) | small, numpy-only; skipped where models can't be downloaded |
| Trial numbers | every table loaded as SQL, with `col__num` and `col__letters` parsed from values like `82.5 b` | exact filtering, nothing retyped |
| Traceability | every hit shows source file, page, table name; documents carry `unverified` / `verified (...)` | what a BAD reviewer checks |

## PDF tables (Camelot)

1. Camelot `lattice` for fully ruled grid tables.
2. For tables with horizontal rules only (journals, EPPO standards, many CRO reports), each `Table N.` caption is located, the area between its rules is taken, column boundaries are read from the header, Camelot `stream` runs on that area only, and wrapped lines are joined back into rows.

Camelot `stream` is never run on whole pages, because on multi-column documents it turns body text into fake tables. Undecoded symbols appear as `(cid:N)` (often ±, ≤, ≥) and are flagged in the notes.

Every document starts `unverified`. Compare its tables with the original pages, fix the CSV and Markdown under `library/docs/` if needed, run `dossier-rag reindex <source>` (re-ingesting would convert again and lose the fixes), then `dossier-rag verify <source> --note "..."`.
